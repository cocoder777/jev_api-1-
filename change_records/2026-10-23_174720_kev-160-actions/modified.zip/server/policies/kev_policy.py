"""Kev decision adapter: eight speeds x twenty locally reachable courses."""
import copy
import json
import logging
import math
import threading
import time
from collections import deque
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import ProxyHandler, Request, build_opener

from choice_control import _candidate_facts
from tools.waypoint_geometry import KNOT_MPS, WaypointGeometry
from .waypoint import WaypointPolicy
from .turning import DEFAULT_MAX_TURN_RATE_DEG_S, reachable_courses
from .waypoint_radius import waypoint_arrival_radius

KEV_SPEEDS_KNOTS = (0., 4., 8., 12., 16., 20., 26., 32.)
DEFAULT_KEV_ENDPOINT = 'http://127.0.0.1:18028/v1/systemone'


def round_model_values(value):
    """Limit model input precision, without rounding internal geometry or physics."""
    if isinstance(value, float):
        result = round(value, 2)
        return 0.0 if result == 0 else result
    if isinstance(value, dict):
        return {key: round_model_values(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [round_model_values(item) for item in value]
    return value


class KevPolicy(WaypointPolicy):
    def __init__(self, endpoint=DEFAULT_KEV_ENDPOINT, timeout=120., client=None, max_turn_rate_deg_s=DEFAULT_MAX_TURN_RATE_DEG_S,
                 initial_course_deg=None, **kwargs):
        super().__init__(**kwargs)
        if urlsplit(endpoint).scheme not in ('http', 'https'):
            raise ValueError('Kev endpoint must be an HTTP(S) URL')
        if not math.isfinite(timeout) or timeout <= 0:
            raise ValueError('Kev timeout must be positive and finite')
        if not math.isfinite(max_turn_rate_deg_s) or max_turn_rate_deg_s <= 0:
            raise ValueError('Max turn rate must be positive and finite')
        if initial_course_deg is not None and (not math.isfinite(initial_course_deg) or not 0 <= initial_course_deg < 360):
            raise ValueError('Initial course must be in [0, 360)')
        self.max_turn_rate_deg_s = max_turn_rate_deg_s
        self.initial_course_deg = initial_course_deg
        self.endpoint, self.timeout, self.client = endpoint, timeout, client
        self._lock = threading.Lock()

    def _observation_course(self, boat):
        """Use the current reported course even when reported speed is zero."""
        course = boat.get('targetCourse')
        if course is None and boat['targetSpeed'] < 1e-6:
            course = self.initial_course_deg
            if course is None:
                raise ValueError('Situation has no targetCourse; provide --initial-course-deg only if no course is reported')
        if (isinstance(course, bool) or not isinstance(course, (int, float))
                or not math.isfinite(course) or not 0 <= course < 360):
            raise ValueError('Missing or invalid situation targetCourse')
        return course

    def observation(self, packet):
        obs = super().observation(packet)
        course = obs['boat']['targetCourse']
        obs['execution'] = {**obs['execution'], 'max_turn_rate_deg_s': self.max_turn_rate_deg_s}
        obs['action_space'] = dict(speeds_knots=list(KEV_SPEEDS_KNOTS), courses_deg=reachable_courses(
            course, self.duration, self.max_turn_rate_deg_s))
        return obs

    def _request(self, obs):
        geometry = WaypointGeometry(obs)
        task, boat = obs['task'], obs['boat']
        index = task['next_waypoint_index']
        distance = math.hypot(*geometry.target)
        limit = task['planWaypointList'][index]['routeSpeed']
        course = boat['targetCourse']
        bearing = math.degrees(math.atan2(geometry.target[0], geometry.target[1])) % 360
        relative_bearing = (bearing-course+180)%360-180
        target_side = 'ahead' if abs(relative_bearing) < .005 else ('left' if relative_bearing < 0 else 'right')
        previous = index - 1
        previous_radius = (waypoint_arrival_radius(task['planWaypointList'][previous])
                           if previous >= 0 else None)
        previous_active = (previous >= 0 and math.hypot(*geometry.waypoints[previous]) <= previous_radius)
        incoming = bearing
        cross_track = None
        if previous >= 0:
            start, end = geometry.waypoints[previous], geometry.target
            dx, dy = end[0] - start[0], end[1] - start[1]
            length = math.hypot(dx, dy)
            if length > 1e-6:
                incoming = math.degrees(math.atan2(dx, dy)) % 360
                cross_track = (dx * -start[1] - dy * -start[0]) / length
        upcoming = None
        outgoing = None
        turn = None
        if index + 1 < len(geometry.waypoints):
            point = task['planWaypointList'][index + 1]
            east, north = geometry.waypoints[index + 1]
            dx, dy = east - geometry.target[0], north - geometry.target[1]
            if math.hypot(dx, dy) > 1e-6:
                outgoing = math.degrees(math.atan2(dx, dy)) % 360
                turn = (outgoing - incoming + 180) % 360 - 180
            upcoming = dict(index=index + 1, east_m=east, north_m=north,
                            passing_speed_ceiling_knots=point['routeSpeed'] / KNOT_MPS,
                            arrival_radius_m=waypoint_arrival_radius(point))
        turn_time = abs(turn) / self.max_turn_rate_deg_s if turn is not None else 0.
        preparation_distance = (boat['targetSpeed'] * KNOT_MPS * (turn_time + self.duration)
                                + task['arrival_radius_m'])
        state = dict(
            task='Visit every mandatory waypoint circle in order. Select speed AND course. Prepare for the next leg before reaching the current waypoint.',
            coordinate_system='East/north; course clockwise from north: 0=N, 90=E, 180=S, 270=W. Negative relative angles=left; positive=right.',
            actual_speed_knots=boat['targetSpeed'], actual_course_deg=course,
            available_speeds_knots=list(KEV_SPEEDS_KNOTS), max_speed_knots=max(KEV_SPEEDS_KNOTS),
            current_waypoint_index=index,
            target_east_m=geometry.target[0], target_north_m=geometry.target[1],
            target_bearing_deg=bearing, target_relative_bearing_deg=relative_bearing,
            target_turn_side=target_side, distance_to_target_m=distance,
            arrival_radius_m=task['arrival_radius_m'],
            passing_speed_ceiling_knots=limit / KNOT_MPS,
            speed_limit_scope='Waypoint circles only, not the whole leg. Below the ceiling is valid; do not chase it as a target speed. Cruise faster between circles up to 32 knots when room allows braking. Do not accelerate until outside the previous circle.',
            previous_circle_active=previous_active,
            previous_circle_speed_ceiling_knots=(task['planWaypointList'][previous]['routeSpeed'] / KNOT_MPS
                                                  if previous_active else None),
            next_waypoint=upcoming, incoming_leg_course_deg=incoming,
            outgoing_leg_course_deg=outgoing, turn_at_waypoint_deg=turn,
            estimated_turn_time_s=turn_time, turn_preparation_distance_m=preparation_distance,
            approaching_corner=turn is not None and abs(turn) > 1. and distance <= preparation_distance,
            cross_track_error_m=cross_track,
            cross_track_convention='Positive=left of incoming leg; negative=right. Unavailable on first leg.',
            command_duration_s=self.duration, max_turn_rate_deg_s=self.max_turn_rate_deg_s,
            max_turn_deg=min(self.max_turn_rate_deg_s*self.duration, 179.99),
            recent_decisions=list(getattr(self.local, 'history', ())),
            forecast_note='Approximate velocity forecasts, not calibrated braking dynamics. Preparation distance estimates travel during the turn, not a guaranteed braking distance.')
        criteria = {}
        for speed_index, speed in enumerate(obs['action_space']['speeds_knots']):
            for heading_index, target_course in enumerate(obs['action_space']['courses_deg']):
                name = f'speed_{speed_index:02d}__heading_{heading_index:02d}'
                facts = _candidate_facts(obs, geometry, speed*KNOT_MPS, target_course,
                    f'{target_course:.2f} deg', distance, limit, previous if previous_active else None,
                    previous_radius=previous_radius)['approximate_effect']
                signed_turn = (target_course-course+180)%360-180
                criteria[name] = dict(speed_knots=speed, absolute_course_deg=target_course,
                    signed_turn_deg=signed_turn,
                    target_heading_error_deg=abs((bearing-target_course+180)%360-180),
                    distance_after_m=facts['end_checkpoint_distance_m'],
                    distance_after_2_steps_m=facts['same_command_preview']['end_checkpoint_distance_m'],
                    speed_limit_violation=(facts['passing_speed_above_ceiling']
                        or facts['same_command_preview']['passing_speed_above_ceiling']
                        or facts.get('previous_circle_speed_above_ceiling', False)),
                    approach_speed_warning=facts['approach_margin_speed_above_ceiling'],
                    estimated_turn_radius_m=(speed*KNOT_MPS/math.radians(self.max_turn_rate_deg_s)
                                             if speed > 0 else None))
        instructions = (
            'First avoid predicted waypoint-circle speed violations. A ceiling is not a desired speed or a whole-leg cap. '
            'Choose lower speeds early near sharp corners, a low passing ceiling, or a large heading error; '
            'use next_waypoint and turn_at_waypoint_deg to prepare, but never skip the current circle. '
            'Outside waypoint circles, prefer efficient faster progress when there is room to slow down. '
            'Choose a turn toward the current target, straight when aligned; avoid repeated reversals. '
            'While completing a corner after waypoint switching, keep speed low until aligned with the new leg. '
            'A target behind may require distance to increase initially. Use zero speed only for necessary braking/stopping; '
            'a zero-speed command does not rotate the boat in this forecast.')
        return round_model_values(dict(model='kev-latest', state=state, questions=dict(action=dict(
            type='choice', instructions=instructions, criteria=criteria))))

    def _call(self, payload):
        if self.client is not None:
            return self.client(payload)
        if not hasattr(self.local, 'opener'):
            self.local.opener = build_opener(ProxyHandler({}))
        request = Request(self.endpoint, data=json.dumps(payload,allow_nan=False).encode(),
                          headers={'Content-Type':'application/json'}, method='POST')
        try:
            with self.local.opener.open(request, timeout=self.timeout) as response:
                return json.load(response)
        except HTTPError as exc:
            raise RuntimeError(f'Kev HTTP {exc.code}: {exc.read(2048).decode(errors="replace")}') from exc
        except (URLError, TimeoutError, OSError, json.JSONDecodeError) as exc:
            raise RuntimeError(f'Local Kev request failed ({self.endpoint}): {exc}') from exc

    def __call__(self, packet):
        obs = self.observation(packet)
        if obs['task']['route_complete']:
            return 0., obs['boat']['targetCourse']
        if getattr(self.local,'kev_task_key',None) != self.local.task_key:
            self.local.kev_task_key = copy.deepcopy(self.local.task_key)
            self.local.history = deque(maxlen=4)
        payload = self._request(obs)
        started = time.perf_counter()
        with self._lock:
            result = self._call(payload)
        if isinstance(result,dict) and result.get('truncated'):
            raise RuntimeError('Kev truncated the model input; refusing a partial-state decision')
        answers = result.get('answers') if isinstance(result,dict) else None
        answer = answers.get('action') if isinstance(answers,dict) else None
        if not isinstance(answer,dict) or answer.get('type') != 'choice':
            raise ValueError('Expected Kev Choice answer for action')
        choice = answer.get('choice')
        criteria = payload['questions']['action']['criteria']
        if not isinstance(choice,str) or choice not in criteria:
            raise ValueError('Kev returned a choice outside the 160 speed/course actions')
        speed = criteria[choice]['speed_knots']
        course = criteria[choice]['absolute_course_deg']
        self.local.last_decision = dict(choice=choice, candidate_count=len(criteria), selection_mode='single_choice',
            speeds_knots=list(KEV_SPEEDS_KNOTS), inference_s=time.perf_counter()-started,
            state=payload['state'], options=payload['questions']['action']['criteria'],
            instructions=payload['questions']['action']['instructions'], result=result)
        self.local.history.append(dict(waypoint_index=obs['task']['next_waypoint_index'],
            distance_m=round(math.hypot(*WaypointGeometry(obs).target), 2), chosen_speed_knots=speed, chosen_course_deg=course))
        logging.getLogger(__name__).debug('Kev inference_s=%.6f choice=%s',
            self.local.last_decision['inference_s'],choice)
        return speed*(KNOT_MPS if self.speed_unit=='mps' else 1.),course
